globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/Ai7y0AQm9JYKV--Qk5rB2/_buildManifest.js",
    "static/Ai7y0AQm9JYKV--Qk5rB2/_ssgManifest.js",
    "static/Ai7y0AQm9JYKV--Qk5rB2/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/2zjueh7t2vecu.js",
    "static/chunks/3ytdv22x5uloo.js",
    "static/chunks/1hc2wgjsgxhih.js",
    "static/chunks/33o0209w1d-93.js",
    "static/chunks/27jktro2p5rq9.js",
    "static/chunks/turbopack-2ob9tfj4nm0y8.js"
  ]
};
