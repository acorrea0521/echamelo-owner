module.exports=[7450,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_bids_place_route_actions_1pge-ye.js.map