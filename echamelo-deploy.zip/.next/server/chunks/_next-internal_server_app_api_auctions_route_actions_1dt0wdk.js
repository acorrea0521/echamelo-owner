module.exports=[819,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_auctions_route_actions_1dt0wdk.js.map