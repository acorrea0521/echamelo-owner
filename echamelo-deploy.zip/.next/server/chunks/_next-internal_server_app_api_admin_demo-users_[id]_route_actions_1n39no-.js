module.exports=[84022,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_demo-users_%5Bid%5D_route_actions_1n39no-.js.map