module.exports=[21051,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_demo-users_route_actions_0rkqwv1.js.map