module.exports=[2825,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_streams_%5Bid%5D_stop_route_actions_1mtdu7c.js.map