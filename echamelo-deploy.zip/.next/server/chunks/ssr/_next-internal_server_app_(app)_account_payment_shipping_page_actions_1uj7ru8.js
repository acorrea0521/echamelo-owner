module.exports=[4935,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28app%29_account_payment_shipping_page_actions_1uj7ru8.js.map