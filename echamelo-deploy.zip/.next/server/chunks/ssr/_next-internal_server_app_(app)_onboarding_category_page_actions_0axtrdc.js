module.exports=[33894,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28app%29_onboarding_category_page_actions_0axtrdc.js.map