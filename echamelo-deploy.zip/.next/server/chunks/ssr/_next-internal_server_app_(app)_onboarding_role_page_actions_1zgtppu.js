module.exports=[18854,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28app%29_onboarding_role_page_actions_1zgtppu.js.map