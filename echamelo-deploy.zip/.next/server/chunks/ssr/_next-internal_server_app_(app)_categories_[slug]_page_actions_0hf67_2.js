module.exports=[23528,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28app%29_categories_%5Bslug%5D_page_actions_0hf67_2.js.map