module.exports=[93695,(a,b,c)=>{b.exports=a.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))},71306,(a,b,c)=>{b.exports=a.r(18622)},79847,a=>{a.n(a.i(3343))},9185,a=>{a.n(a.i(29432))},72842,a=>{a.n(a.i(75164))},54897,a=>{a.n(a.i(30106))},56157,a=>{a.n(a.i(18970))},94331,a=>{a.n(a.i(60644))},15988,a=>{a.n(a.i(56952))},25766,a=>{a.n(a.i(77341))},29725,a=>{a.n(a.i(94290))},90833,a=>{a.n(a.i(46994))},5785,a=>{a.n(a.i(90588))},74793,a=>{a.n(a.i(33169))},85826,a=>{a.n(a.i(37111))},21565,a=>{a.n(a.i(41763))},65911,a=>{a.n(a.i(8950))},25128,a=>{a.n(a.i(91562))},40781,a=>{a.n(a.i(5591))},69411,a=>{a.n(a.i(75700))},63081,a=>{a.n(a.i(276))},62837,a=>{a.n(a.i(40795))},34607,a=>{a.n(a.i(11614))},96338,a=>{a.n(a.i(21751))},50642,a=>{a.n(a.i(12213))},32242,a=>{a.n(a.i(22693))},88530,a=>{a.n(a.i(10531))},8583,a=>{a.n(a.i(1082))},38534,a=>{a.n(a.i(98175))},70408,a=>{a.n(a.i(9095))},22922,a=>{a.n(a.i(96772))},78294,a=>{a.n(a.i(71717))},16625,a=>{a.n(a.i(12214))},88648,a=>{a.n(a.i(68113))},51914,a=>{a.n(a.i(66482))},25466,a=>{a.n(a.i(91505))},80162,a=>{"use strict";a.s(["CategoriesLayout",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call CategoriesLayout() from the server but CategoriesLayout is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/components/categories/CategoriesLayout.tsx <module evaluation>","CategoriesLayout")},33431,a=>{"use strict";a.s(["CategoriesLayout",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call CategoriesLayout() from the server but CategoriesLayout is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/components/categories/CategoriesLayout.tsx","CategoriesLayout")},33805,a=>{"use strict";a.i(80162);var b=a.i(33431);a.n(b)},18385,a=>{"use strict";var b=a.i(7997),c=a.i(98310),d=a.i(33805);function e({children:a}){return(0,b.jsxs)(b.Fragment,{children:[(0,b.jsx)("style",{children:`
        * {
          box-sizing: border-box;
          margin: 0;
          padding: 0;
          -webkit-tap-highlight-color: transparent;
        }
        :root {
          --bg: #0D0D0D;
          --s1: #181818;
          --s2: #1e1e1e;
          --s3: #2a2a2a;
          --gold: #F5C842;
          --gold2: #C8961A;
          --red: #E63946;
          --green: #2DC653;
          --blue: #378ADD;
          --txt: #F0EDE8;
          --mute: #888;
          --brd: #2e2e2e;
          --fh: 'Syne', sans-serif;
          --fb: 'Nunito', sans-serif;
        }
        html, body {
          height: 100% !important;
          height: 100dvh !important;
          margin: 0 !important;
          padding: 0 !important;
          overflow: hidden !important;
          overscroll-behavior: none !important;
          width: 100% !important;
        }
        body {
          color: var(--txt);
          font-family: var(--fb);
          font-size: 14px;
          background: var(--bg) !important;
          display: block !important;
        }
        * {
          scrollbar-width: none;
          -ms-overflow-style: none;
        }
        *::-webkit-scrollbar {
          display: none !important;
          width: 0 !important;
          height: 0 !important;
        }

        /* animations */
        @keyframes fadeUp {
          from {
            opacity: 0;
            transform: translateY(16px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        @keyframes fadeIn {
          from {
            opacity: 0;
          }
          to {
            opacity: 1;
          }
        }
        @keyframes bounceIn {
          0% {
            transform: scale(0.3);
            opacity: 0;
          }
          55% {
            transform: scale(1.1);
          }
          75% {
            transform: scale(0.93);
          }
          100% {
            transform: scale(1);
            opacity: 1;
          }
        }
        @keyframes float {
          0%, 100% {
            transform: translateY(0);
          }
          50% {
            transform: translateY(-9px);
          }
        }
        @keyframes glow {
          0%, 100% {
            text-shadow: 0 0 22px #F5C84244;
          }
          50% {
            text-shadow: 0 0 48px #F5C842aa;
          }
        }
        @keyframes shimmer {
          0% {
            left: -120%;
          }
          100% {
            left: 220%;
          }
        }
        @keyframes tickMove {
          0% {
            transform: translateX(0);
          }
          100% {
            transform: translateX(-50%);
          }
        }
        @keyframes pulse {
          0%, 100% {
            opacity: 1;
          }
          50% {
            opacity: 0.25;
          }
        }
        @keyframes liveRing {
          0%, 100% {
            box-shadow: 0 0 0 0 rgba(230, 57, 70, 0.5);
          }
          50% {
            box-shadow: 0 0 0 14px rgba(230, 57, 70, 0);
          }
        }
        @keyframes checkPop {
          0% {
            transform: scale(0);
          }
          70% {
            transform: scale(1.2);
          }
          100% {
            transform: scale(1);
          }
        }
      `}),(0,b.jsx)("link",{rel:"stylesheet",href:"https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@latest/tabler-icons.min.css"}),(0,b.jsx)("link",{href:"https://fonts.googleapis.com/css2?family=Syne:wght@700;800;900&family=Nunito:wght@400;600;700;800&display=swap",rel:"stylesheet"}),a]})}async function f(){let a=await (0,c.createClient)(),[{data:f},{data:g}]=await Promise.all([a.from("categories").select("id, name, slug, icon").order("sort_order"),a.from("streams").select("viewer_count, seller:profiles!streams_seller_id_fkey(category_id)").eq("status","live")]),h=new Map;for(let a of g??[]){let b=a.seller?.category_id;b&&h.set(b,(h.get(b)??0)+a.viewer_count)}let i=(f??[]).map(a=>({id:a.id,name:a.name,slug:a.slug,icon:a.icon,viewerCount:h.get(a.id)??0}));return(0,b.jsx)(e,{children:(0,b.jsx)(d.CategoriesLayout,{categories:i})})}a.s(["default",0,f],18385)},21723,a=>{a.n(a.i(18385))}];

//# sourceMappingURL=%5Broot-of-the-server%5D__1lcbbe0._.js.map