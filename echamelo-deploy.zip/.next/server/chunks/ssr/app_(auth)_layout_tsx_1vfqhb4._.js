module.exports=[12498,a=>{"use strict";var b=a.i(7997);a.s(["default",0,function({children:a}){return(0,b.jsx)("div",{className:"mx-auto flex min-h-dvh w-full max-w-sm flex-col justify-center gap-6 bg-background px-6 py-6",children:a})}])},86024,a=>{a.n(a.i(12498))}];

//# sourceMappingURL=app_%28auth%29_layout_tsx_1vfqhb4._.js.map