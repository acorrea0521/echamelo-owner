module.exports=[94905,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28app%29_chat_support_page_actions_0222kfn.js.map