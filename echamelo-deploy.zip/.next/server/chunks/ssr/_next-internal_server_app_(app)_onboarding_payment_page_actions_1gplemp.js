module.exports=[60741,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28app%29_onboarding_payment_page_actions_1gplemp.js.map