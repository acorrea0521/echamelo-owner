module.exports=[67810,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_go-live_page_actions_0-eir13.js.map