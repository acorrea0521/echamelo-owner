module.exports=[9745,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_streams_page_actions_1oprrlc.js.map