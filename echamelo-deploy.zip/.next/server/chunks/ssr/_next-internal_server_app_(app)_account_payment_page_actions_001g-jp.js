module.exports=[96940,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28app%29_account_payment_page_actions_001g-jp.js.map