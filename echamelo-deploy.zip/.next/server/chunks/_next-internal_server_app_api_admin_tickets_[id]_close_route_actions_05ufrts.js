module.exports=[9914,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_tickets_%5Bid%5D_close_route_actions_05ufrts.js.map