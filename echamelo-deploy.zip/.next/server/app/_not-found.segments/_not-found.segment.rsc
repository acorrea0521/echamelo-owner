1:"$Sreact.fragment"
2:I[39756,["/_next/static/chunks/170l171_3-f8c.js","/_next/static/chunks/14mrh2-p_w84d.js","/_next/static/chunks/3cj9p54vu2_hd.js"],"default"]
3:I[37457,["/_next/static/chunks/170l171_3-f8c.js","/_next/static/chunks/14mrh2-p_w84d.js","/_next/static/chunks/3cj9p54vu2_hd.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"Ai7y0AQm9JYKV--Qk5rB2"}
