var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/auctions/[listingId]/bot-tick/route.js")
R.c("server/chunks/[root-of-the-server]__0cxknl1._.js")
R.c("server/chunks/_0357td0._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/1oeh_server_app_api_auctions_[listingId]_bot-tick_route_actions_0u3-v33.js")
R.m(13097)
module.exports=R.m(13097).exports
