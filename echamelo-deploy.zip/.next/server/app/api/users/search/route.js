var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/users/search/route.js")
R.c("server/chunks/[root-of-the-server]__0fbl1yp._.js")
R.c("server/chunks/_0357td0._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_users_search_route_actions_1r1lwxg.js")
R.m(55499)
module.exports=R.m(55499).exports
