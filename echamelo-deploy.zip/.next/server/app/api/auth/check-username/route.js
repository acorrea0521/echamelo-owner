var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/check-username/route.js")
R.c("server/chunks/[root-of-the-server]__0es1ug9._.js")
R.c("server/chunks/_0357td0._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_check-username_route_actions_1cki74v.js")
R.m(62841)
module.exports=R.m(62841).exports
