var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/listings/route.js")
R.c("server/chunks/[root-of-the-server]__1o6g04r._.js")
R.c("server/chunks/_0357td0._.js")
R.c("server/chunks/node_modules_zod_v4_classic_external_1-pw2v2.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_listings_route_actions_1cs2ev1.js")
R.m(51101)
module.exports=R.m(51101).exports
