var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/listings/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__1p-d36n._.js")
R.c("server/chunks/_0357td0._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_listings_[id]_route_actions_1120t4l.js")
R.m(42386)
module.exports=R.m(42386).exports
