var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/listings/[id]/start-auction/route.js")
R.c("server/chunks/[root-of-the-server]__08abufc._.js")
R.c("server/chunks/_0357td0._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_listings_[id]_start-auction_route_actions_1cs6pix.js")
R.m(20677)
module.exports=R.m(20677).exports
