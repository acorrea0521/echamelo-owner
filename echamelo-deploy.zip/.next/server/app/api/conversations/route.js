var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/conversations/route.js")
R.c("server/chunks/[root-of-the-server]__0iw3rla._.js")
R.c("server/chunks/_0357td0._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_conversations_route_actions_1-pu7gs.js")
R.m(16906)
module.exports=R.m(16906).exports
