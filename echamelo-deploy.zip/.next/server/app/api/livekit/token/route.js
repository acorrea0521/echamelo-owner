var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/livekit/token/route.js")
R.c("server/chunks/[root-of-the-server]__219z_8z._.js")
R.c("server/chunks/_0357td0._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/[root-of-the-server]__1bw6cat._.js")
R.c("server/chunks/_next-internal_server_app_api_livekit_token_route_actions_1jvabuc.js")
R.m(81341)
module.exports=R.m(81341).exports
