var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/livekit/webhook/route.js")
R.c("server/chunks/[root-of-the-server]__1l6hehd._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/[root-of-the-server]__1bw6cat._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/_next-internal_server_app_api_livekit_webhook_route_actions_1z03ju2.js")
R.m(3618)
module.exports=R.m(3618).exports
