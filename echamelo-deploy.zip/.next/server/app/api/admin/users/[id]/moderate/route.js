var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/users/[id]/moderate/route.js")
R.c("server/chunks/[root-of-the-server]__10p3bjd._.js")
R.c("server/chunks/_0357td0._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_users_[id]_moderate_route_actions_1il09l2.js")
R.m(21258)
module.exports=R.m(21258).exports
