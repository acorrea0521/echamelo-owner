var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/streams/[id]/force-stop/route.js")
R.c("server/chunks/[root-of-the-server]__0i6s_3b._.js")
R.c("server/chunks/_0357td0._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/[root-of-the-server]__1bw6cat._.js")
R.c("server/chunks/1oeh_server_app_api_admin_streams_[id]_force-stop_route_actions_06y3nvc.js")
R.m(67259)
module.exports=R.m(67259).exports
