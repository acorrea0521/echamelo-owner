var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/demo-users/route.js")
R.c("server/chunks/[root-of-the-server]__0z52upe._.js")
R.c("server/chunks/_0357td0._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_demo-users_route_actions_0rkqwv1.js")
R.m(57939)
module.exports=R.m(57939).exports
