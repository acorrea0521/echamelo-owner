var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/tickets/[id]/open/route.js")
R.c("server/chunks/[root-of-the-server]__16btago._.js")
R.c("server/chunks/_0357td0._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_tickets_[id]_open_route_actions_08ok4z4.js")
R.m(63158)
module.exports=R.m(63158).exports
