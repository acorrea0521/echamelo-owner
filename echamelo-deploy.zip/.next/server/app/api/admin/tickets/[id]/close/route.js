var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/tickets/[id]/close/route.js")
R.c("server/chunks/[root-of-the-server]__0lr94uj._.js")
R.c("server/chunks/_0357td0._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_tickets_[id]_close_route_actions_05ufrts.js")
R.m(77371)
module.exports=R.m(77371).exports
