var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/sellers/[id]/bot-config/route.js")
R.c("server/chunks/[root-of-the-server]__1w05t-p._.js")
R.c("server/chunks/_0357td0._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/1oeh_server_app_api_admin_sellers_[id]_bot-config_route_actions_1zi1pc0.js")
R.m(6003)
module.exports=R.m(6003).exports
