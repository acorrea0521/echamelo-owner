var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/seller-applications/[id]/request-changes/route.js")
R.c("server/chunks/[root-of-the-server]__0yz4zr9._.js")
R.c("server/chunks/_0357td0._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/1jng_app_api_admin_seller-applications_[id]_request-changes_route_actions_0rx-8-t.js")
R.m(53878)
module.exports=R.m(53878).exports
