var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/seller-applications/[id]/approve/route.js")
R.c("server/chunks/[root-of-the-server]__0ylfu7x._.js")
R.c("server/chunks/_0357td0._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/1oeh_server_app_api_admin_seller-applications_[id]_approve_route_actions_0numb85.js")
R.m(34705)
module.exports=R.m(34705).exports
