var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/stripe/connect/onboarding-link/route.js")
R.c("server/chunks/[root-of-the-server]__061jefn._.js")
R.c("server/chunks/_0357td0._.js")
R.c("server/chunks/lib_stripe_client_ts_1iyjhz4._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/1oeh_server_app_api_stripe_connect_onboarding-link_route_actions_0_quvnk.js")
R.m(64780)
module.exports=R.m(64780).exports
