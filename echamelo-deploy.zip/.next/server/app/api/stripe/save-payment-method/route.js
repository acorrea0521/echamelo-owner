var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/stripe/save-payment-method/route.js")
R.c("server/chunks/[root-of-the-server]__176tq5h._.js")
R.c("server/chunks/_0357td0._.js")
R.c("server/chunks/lib_stripe_client_ts_1iyjhz4._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_stripe_save-payment-method_route_actions_0pcl30-.js")
R.m(20295)
module.exports=R.m(20295).exports
