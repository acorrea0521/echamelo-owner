var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/stripe/identity/buyer-session/route.js")
R.c("server/chunks/[root-of-the-server]__0chhlwc._.js")
R.c("server/chunks/_0357td0._.js")
R.c("server/chunks/lib_stripe_client_ts_1iyjhz4._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/1oeh_server_app_api_stripe_identity_buyer-session_route_actions_0ja1j-w.js")
R.m(13141)
module.exports=R.m(13141).exports
