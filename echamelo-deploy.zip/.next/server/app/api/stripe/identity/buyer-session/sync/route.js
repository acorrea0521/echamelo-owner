var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/stripe/identity/buyer-session/sync/route.js")
R.c("server/chunks/[root-of-the-server]__1e1ohaq._.js")
R.c("server/chunks/_0357td0._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/lib_stripe_client_ts_1iyjhz4._.js")
R.c("server/chunks/1oeh_server_app_api_stripe_identity_buyer-session_sync_route_actions_112hsoa.js")
R.m(26304)
module.exports=R.m(26304).exports
