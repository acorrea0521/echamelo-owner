var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/stripe/setup-intent/route.js")
R.c("server/chunks/[root-of-the-server]__17o68pz._.js")
R.c("server/chunks/_0357td0._.js")
R.c("server/chunks/lib_stripe_client_ts_1iyjhz4._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_stripe_setup-intent_route_actions_1a9kxbe.js")
R.m(68524)
module.exports=R.m(68524).exports
