var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/streams/[id]/go-live/route.js")
R.c("server/chunks/[root-of-the-server]__0thea70._.js")
R.c("server/chunks/_0357td0._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_streams_[id]_go-live_route_actions_0iw29s_.js")
R.m(37716)
module.exports=R.m(37716).exports
