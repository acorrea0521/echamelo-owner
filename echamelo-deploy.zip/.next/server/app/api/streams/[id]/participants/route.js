var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/streams/[id]/participants/route.js")
R.c("server/chunks/[root-of-the-server]__1293-ti._.js")
R.c("server/chunks/_0357td0._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/[root-of-the-server]__1bw6cat._.js")
R.c("server/chunks/_next-internal_server_app_api_streams_[id]_participants_route_actions_0v4y4us.js")
R.m(54696)
module.exports=R.m(54696).exports
