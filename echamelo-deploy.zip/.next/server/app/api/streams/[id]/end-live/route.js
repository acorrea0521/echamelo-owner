var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/streams/[id]/end-live/route.js")
R.c("server/chunks/[root-of-the-server]__0968xre._.js")
R.c("server/chunks/_0357td0._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_streams_[id]_end-live_route_actions_1xf8sli.js")
R.m(73153)
module.exports=R.m(73153).exports
