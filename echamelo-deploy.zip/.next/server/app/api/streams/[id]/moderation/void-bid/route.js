var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/streams/[id]/moderation/void-bid/route.js")
R.c("server/chunks/[root-of-the-server]__1xp-o9k._.js")
R.c("server/chunks/_0357td0._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/1oeh_server_app_api_streams_[id]_moderation_void-bid_route_actions_199rb5w.js")
R.m(82926)
module.exports=R.m(82926).exports
