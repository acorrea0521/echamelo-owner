var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/streams/[id]/moderation/chat-pause/route.js")
R.c("server/chunks/[root-of-the-server]__1y-i4zi._.js")
R.c("server/chunks/_0357td0._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/1oeh_server_app_api_streams_[id]_moderation_chat-pause_route_actions_0p4mrn7.js")
R.m(79316)
module.exports=R.m(79316).exports
