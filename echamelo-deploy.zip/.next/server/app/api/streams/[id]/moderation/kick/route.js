var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/streams/[id]/moderation/kick/route.js")
R.c("server/chunks/[root-of-the-server]__0uwnu-x._.js")
R.c("server/chunks/_0357td0._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/[root-of-the-server]__1bw6cat._.js")
R.c("server/chunks/_next-internal_server_app_api_streams_[id]_moderation_kick_route_actions_1n3v9e2.js")
R.m(93714)
module.exports=R.m(93714).exports
