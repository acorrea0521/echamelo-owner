var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/streams/preview/route.js")
R.c("server/chunks/[root-of-the-server]__0cyq2nu._.js")
R.c("server/chunks/_0357td0._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_streams_preview_route_actions_1cgy6q4.js")
R.m(1216)
module.exports=R.m(1216).exports
