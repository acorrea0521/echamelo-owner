var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/bids/place/route.js")
R.c("server/chunks/[root-of-the-server]__06gngc4._.js")
R.c("server/chunks/_0357td0._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/lib_stripe_client_ts_1iyjhz4._.js")
R.c("server/chunks/_next-internal_server_app_api_bids_place_route_actions_1pge-ye.js")
R.m(71107)
module.exports=R.m(71107).exports
