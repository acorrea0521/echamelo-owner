var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/(auth)/auth/callback/route.js")
R.c("server/chunks/[root-of-the-server]__1ts3d4h._.js")
R.c("server/chunks/_0357td0._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_(auth)_auth_callback_route_actions_1acxkr0.js")
R.m(691)
module.exports=R.m(691).exports
